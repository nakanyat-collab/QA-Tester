
const { test, expect } = require('@playwright/test');

const URL = 'https://portal.uat.gofive.co.th/Register/empeo';


// ============================================================
// TC-01: Registration Page Loads Successfully
// Type: Positive Testing
// ============================================================

test('TC-01: Registration page loads successfully', async ({ page }) => {

  // Step 1: Open registration page
  const response = await page.goto(URL);

  // Step 2: Verify HTTP response
  expect(response).not.toBeNull();
  expect(response.ok()).toBeTruthy();

  // Step 3: Verify registration URL
  await expect(page).toHaveURL(/\/Register\/empeo\/?$/);

  // Step 4: Verify registration heading
  await expect(
    page.getByText('ทดลองใช้งาน empeo ฟรี!', { exact: true })
  ).toBeVisible();

  // Step 5: Verify registration button
  await expect(
    page.getByRole('button', { name: 'ทดลองใช้ฟรี' })
  ).toBeVisible();

});


// ============================================================
// TC-02: Submit Empty Registration Form
// Type: Negative Testing
// ============================================================

test('TC-02: Submit empty registration form', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Submit without entering any data
  await page.getByRole('button', { name: 'ทดลองใช้ฟรี' }).click();

  // Step 3: Verify validation messages
  const requiredErrors = [
    'กรุณากรอกเลขประจำตัวผู้เสียภาษีหรือชื่อบริษัท',
    'กรุณากรอกประเภทธุรกิจ',
    'กรุณากรอกผู้ใช้งาน',
    'กรุณากรอกอีเมล',
    'กรุณากรอกชื่อ',
    'กรุณากรอกนามสกุล',
    'กรุณากรอกเบอร์โทรศัพท์มือถือ'
  ];

  for (const error of requiredErrors) {
    await expect(
      page.getByText(error, { exact: true })
    ).toBeVisible();
  }

  // Step 4: Verify user remains on registration page
  await expect(page).toHaveURL(/\/Register\/empeo\/?$/);

});


// ============================================================
// TC-03: Invalid Email Format
// Type: Negative Testing
// ============================================================

test('TC-03: Invalid email format', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Enter invalid email automatically
  const emailInput = page.locator('input[placeholder*="อีเมล"]');

  await expect(emailInput).toBeVisible();
  await emailInput.fill('test@');

  // Step 3: Click registration button
  await page.getByRole('button', { name: 'ทดลองใช้ฟรี' }).click();

  // Step 4: Verify invalid email validation message
  await expect(
    page.getByText('กรุณาใส่อีเมลที่ถูกต้อง', { exact: true })
  ).toBeVisible();

  // Step 5: Verify user remains on registration page
  await expect(page).toHaveURL(/\/Register\/empeo\/?$/);

});




﻿// ============================================================
// TC-04: Invalid Phone Number
// Type: Negative Testing
// ============================================================

test('TC-04: Invalid phone number', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Enter invalid phone number automatically
  const phoneInput = page.locator('input[placeholder*="เบอร์มือถือ"]');

  await expect(phoneInput).toBeVisible();
  await phoneInput.fill('12345');

  // Step 3: Verify entered phone number
  await expect(phoneInput).toHaveValue('12345');

  // Step 4: Click registration button
  await page.getByRole('button', { name: 'ทดลองใช้ฟรี' }).click();

  // Step 5: Verify invalid phone validation message
  await expect(
    page.getByText('รูปแบบเบอร์โทรศัพท์ไม่ถูกต้อง', { exact: true })
  ).toBeVisible();

  // Step 6: Verify user remains on registration page
  await expect(page).toHaveURL(/\/Register\/empeo\/?$/);

});




﻿// ============================================================
// TC-05: Valid Registration Information
// Type: Positive Testing
// ============================================================

test('TC-05: Enter valid registration information', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Prepare valid test data
  const testData = {
    email: 'qa.test@example.com',
    firstName: 'Test',
    lastName: 'User',
    phone: '0967690708'
  };

  // Step 3: Fill registration information
  const emailInput = page.locator('input[placeholder*="อีเมล"]');
  const firstNameInput = page.locator('input[placeholder="ชื่อ*"]');
  const lastNameInput = page.locator('input[placeholder="นามสกุล*"]');
  const phoneInput = page.locator('input[placeholder*="เบอร์มือถือ"]');

  await emailInput.fill(testData.email);
  await firstNameInput.fill(testData.firstName);
  await lastNameInput.fill(testData.lastName);
  await phoneInput.fill(testData.phone);

  // Step 4: Verify entered information
  await expect(emailInput).toHaveValue(testData.email);
  await expect(firstNameInput).toHaveValue(testData.firstName);
  await expect(lastNameInput).toHaveValue(testData.lastName);
  await expect(phoneInput).toHaveValue(testData.phone);

  // Step 5: Verify registration page remains open
  await expect(page).toHaveURL(/\/Register\/empeo\/?$/);

  // Do not submit the form yet
});



﻿// ============================================================
// TC-06: Terms & Conditions Checkbox
// Type: Positive / Negative Testing
// ============================================================

test('TC-06: Terms and conditions checkbox behavior', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Locate checkbox
  const termsCheckbox = page.getByRole('checkbox');

  // Step 3: Verify checkbox is unchecked by default
  await expect(termsCheckbox).not.toBeChecked();

  // Step 4: Accept terms
  await termsCheckbox.check();

  // Step 5: Verify checkbox is checked
  await expect(termsCheckbox).toBeChecked();

  // Step 6: Uncheck terms
  await termsCheckbox.uncheck();

  // Step 7: Verify checkbox is unchecked again
  await expect(termsCheckbox).not.toBeChecked();

});




﻿// ============================================================
// TC-07: Promo Code
// Type: Positive Testing
// ============================================================

test('TC-07: Promo code input', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Click promo code section
  await page.getByText('ใช้โค้ดส่วนลด', { exact: true }).click();

  // Step 3: Inspect visible input fields
  const inputFields = await page.locator('input:visible').evaluateAll(
    elements => elements.map(element => ({
      placeholder: element.getAttribute('placeholder'),
      type: element.getAttribute('type'),
      outerHTML: element.outerHTML
    }))
  );

  console.log('=== VISIBLE INPUT FIELDS ===');
  console.log(JSON.stringify(inputFields, null, 2));

  // Step 4: Verify promo code input is available
  const promoInput = page.locator(
    'input[placeholder*="โค้ด"], ' +
    'input[placeholder*="ส่วนลด"], ' +
    'input[placeholder*="Promo"], ' +
    'input[placeholder*="promo"]'
  );

  await expect(promoInput).toBeVisible();

  // Step 5: Enter promo code automatically
  await promoInput.fill('FREE15DAY');

  // Step 6: Verify entered promo code
  await expect(promoInput).toHaveValue('FREE15DAY');

  // Do not submit registration form
});




﻿// ============================================================
// TC-08: OTP Verification
// Type: Positive / Negative Testing
// ============================================================

test('TC-08: OTP verification', async ({ page }) => {

  // Step 1: Open registration page
  await page.goto(URL);

  // Step 2: Prepare OTP test data
  const testData = {
    phone: '0967690708',
    validOTP: '123456',
    invalidOTP: '000000'
  };

  // Step 3: Check whether OTP input is available
  const otpInput = page.locator(
    'input[autocomplete="one-time-code"], ' +
    'input[placeholder*="OTP"], ' +
    'input[placeholder*="รหัสยืนยัน"]'
  );

  const otpCount = await otpInput.count();

  console.log('OTP input count:', otpCount);

  // Step 4: Report unavailable OTP step
  if (otpCount === 0) {
    console.log(
      'BLOCKED: OTP screen is not accessible from the initial registration page.'
    );

    test.skip(
      true,
      'OTP step requires completion of the registration flow.'
    );
  }

  // Step 5: Verify OTP field is visible
  await expect(otpInput.first()).toBeVisible();

  // Step 6: Enter invalid OTP
  await otpInput.first().fill(testData.invalidOTP);

  // Step 7: Verify invalid OTP was entered
  await expect(otpInput.first()).toHaveValue(testData.invalidOTP);

  // Step 8: Do not submit OTP without verified flow
  console.log('OTP field inspected. Verification submission not performed.');

});
